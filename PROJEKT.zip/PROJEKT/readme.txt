https://www.mongodb.com/ + mongoDBCompass

login do MongoDB
19nowakowski98@gmail.com

link do baz danych:
mongodb+srv://Jakub:Nowakowski@bazadanych.ax71u.mongodb.net/myFirstDatabase?retryWrites=true&w=majority

link do strony startowej: http://localhost:3000/

polecenie w terminalu: node server.js