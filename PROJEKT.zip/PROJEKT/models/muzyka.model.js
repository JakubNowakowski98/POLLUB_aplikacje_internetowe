const mongoose = require("mongoose")
let muzykaSchema = new mongoose.Schema({
    Autor: {
        type: String,
        required: 'This field is required'
    },
    IDplaylisty: {
        type: String,
        required: 'This field is required'
    },
    Tytul: {
        type: String,
        required: 'This field is required'
    },
    linkYT: {
        type: String,
        required: 'This field is required'
    }
})
mongoose.model("Muzyka", muzykaSchema)