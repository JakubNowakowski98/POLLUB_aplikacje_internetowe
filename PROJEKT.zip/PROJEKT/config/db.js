const mongoose = require("mongoose")
module.exports = {
    mongoURI: "mongodb+srv://Jakub:Nowakowski@bazadanych.ax71u.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    secretOrKey: "secret"
};

require("../models/muzyka.model")
